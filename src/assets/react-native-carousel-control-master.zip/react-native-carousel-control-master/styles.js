import { StyleSheet } from "react-native";
let styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center",
        alignSelf: "stretch"
    },
    page: {
        flex: 1
    }
});

export default styles;
