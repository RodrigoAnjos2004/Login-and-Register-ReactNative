# threejs-character-controls-example
threejs-character-controls-example

`npm install` and `npm run start`  
  
Try the [Stackblitz](https://stackblitz.com/github/tamani-coding/threejs-character-controls-example)  
  
Checkout the file `characterControls.ts` for the character controller implementation.

![Screenshot](https://github.com/tamani-coding/threejs-character-controls-example/blob/main/screenshot01.png?raw=true)